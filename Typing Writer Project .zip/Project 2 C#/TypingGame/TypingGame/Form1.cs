﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TypingGame
{
    public partial class Form1 : Form
    {

        private string[] sentences = new string[]
        {
            "Hello World",
            "The dog is running",
            "Earth is round",
            "You are lazy"
        };
        private string currentSentences;
        private int currentCharIndex;
        private Hashtable accuracyTable;
        private List<char> typedChars;

        public Form1()
        {
            InitializeComponent();
            accuracyTable = new Hashtable();
            typedChars = new List<char>();
            textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            buttonStart.Click += new EventHandler(this.buttonStart_Click);
            buttonQuit.Click += new EventHandler(this.buttonQuit_Click);
        }

        private void ButtonQuit_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void StartNewGame()
        {
            Random random = new Random();
            currentSentences = sentences[random.Next(sentences.Length)];
            currentCharIndex = 0;
            typedChars.Clear();
            labelSentence.Text = currentSentences;
            textBox1.Clear();
            listBoxAccuracy.Items.Clear();
            UpdateAccuracyDisplay();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
             if(currentCharIndex < currentSentences.Length)
            {
                char expectedChar = currentSentences[currentCharIndex];
                char typedChar = e.KeyChar;
                typedChars.Add(typedChar);
                
                if(typedChar == expectedChar )
                {
                    currentCharIndex++;
                }

                UpdateAccuracy(typedChar, typedChar == expectedChar);
                UpdateTypingProgress();
                UpdateAccuracyDisplay();
            }

             e.Handled = true;
        }

        private void UpdateTypingProgress()
        {
            StringBuilder progress = new StringBuilder();
            for( int i = 0; i < currentCharIndex; i++ )
            {
                progress.Append(currentSentences[i]);
            }
            textBox1.Text = progress.ToString();
            textBox1.SelectionStart = textBox1.Text.Length;
        }

        private void UpdateAccuracy(char typedChar, bool isCorrect)
        {
            if (!accuracyTable.ContainsKey(typedChar))
            {
                accuracyTable[typedChar] = new List<int> { 0, 0 };
            }

            var counts = (List<int>)accuracyTable[typedChar];
            if(isCorrect)
            {
                counts[0]++;
            }
            counts[1]++;
        }

        private void UpdateAccuracyDisplay()
        {
            listBoxAccuracy.Items.Clear();
            foreach (DictionaryEntry entry in accuracyTable)
            {
                char character = (char)entry.Key;
                var counts = (List<int>) entry.Value;
                listBoxAccuracy.Items.Add($"{character}:{counts[0]}/{counts[1]}");
            }
        }
    }
}
