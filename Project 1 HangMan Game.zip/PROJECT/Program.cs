﻿using System;

namespace HangManGame 
{
    class Program
    {
        private static string[] WORDS = { "apple", "cat", "dolphin", "mouse", "world" };
        private static List<char> correctGuesses = new List<char>();
        private static List<char> incorrectGuesses = new List<char>();
        private static int wrongGuessesCount = 0;
        private static int mostGuesses = int.MaxValue;
        private static SortedList<string, int> scoreboard = new SortedList<string, int>();

        public class ProgramHelpers
        {
            public static string? currentWord;
        }

        static void Main(string[] args)
        {
            StartNewGame();
            while (true)
            {
                ConsoleKeyInfo keyInfo = Console.ReadKey();
                char guessedLetter = keyInfo.KeyChar;
                if (char.IsLetter(guessedLetter))
                {
                    HandleGuess(guessedLetter);
                }
            }

        }

        private static void StartNewGame()
        {
            //To Reset the game 
            correctGuesses.Clear();
            incorrectGuesses.Clear();
            wrongGuessesCount = 0;

            //Selecting a random word. 
            Random random = new Random();
            ProgramHelpers.currentWord = WORDS[random.Next(WORDS.Length)];

            //This is to display the word with underscores. 
            UpdateWordDisplay();

            //Updating the things
            // UpdatScoreboard();
            UpdateIncorrectGuesses();

        }

        private static void UpdateWordDisplay()
        {
            //building the display string
            string display = "";
            foreach (char letter in ProgramHelpers.currentWord)
            {
                if (correctGuesses.Contains(letter))
                {
                    display += letter;
                }
                else
                {
                    display += "_";
                }
            }
            Console.WriteLine(display);
        }

        private static void UpdatScoreboard()
        {
            Console.WriteLine("Scoreboard:");
            foreach (var score in scoreboard)
            {
                Console.WriteLine($"{score.Key}:{score.Value}");
            }
        }

        private static void UpdateIncorrectGuesses()
        {
            //displaying the incorrect guesses
           // Console.WriteLine($",Is Incorrect");
            Console.WriteLine($" Incorrect Guesses: {String.Join(",", incorrectGuesses)}");
        }

        private static void HandleGuess(char guessedLetter)
        {
            //checking if the guessed letter are in the word itself
            if (ProgramHelpers.currentWord.Contains(guessedLetter))
            {
                if (!correctGuesses.Contains(guessedLetter))
                {
                    correctGuesses.Add(guessedLetter);
                    UpdateWordDisplay();
                }
            }
            else
            {
                if (!incorrectGuesses.Contains(guessedLetter))
                {
                    incorrectGuesses.Add(guessedLetter);
                    wrongGuessesCount++;
                    UpdateIncorrectGuesses();
                }
            }
            //checking if they won the game.
            if (ProgramHelpers.currentWord.All(correctGuesses.Contains))
            {
                Console.WriteLine("CONGRATS!! YOU WON THE GAME");
                if(wrongGuessesCount < mostGuesses)
                {
                    mostGuesses = wrongGuessesCount;
                    scoreboard[ProgramHelpers.currentWord] = mostGuesses;
                    UpdatScoreboard();
                }
                StartNewGame();
            }

            //checking if they lost the game
            if (wrongGuessesCount >= 10)
            {
                Console.WriteLine("Game over!! You Have Lost.");
                StartNewGame();
            }
        }
    }
}
