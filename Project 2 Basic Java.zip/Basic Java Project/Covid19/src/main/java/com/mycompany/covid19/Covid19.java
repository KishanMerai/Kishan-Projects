
package com.mycompany.covid19;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

public class Covid19 {
    
    

public class ProvincialDetails implements Serializable {
    private String province;
    private int TotalCases;
    private double PercentageTotal;

    public ProvincialDetails() {
    }

    public ProvincialDetails(String province, int totalCases, double PercentageTotal) {
        this.province = province;
        this.TotalCases = totalCases;
        this.PercentageTotal = PercentageTotal;
    }

    // Get and set 
    

    @Override
    public String toString() {
        return "Province: " + province +
                ", Total Cases: " + TotalCases +
                ", Percentage Total: " + PercentageTotal;
    }
}






public class CovidApp {
    private static final String JDBC_URL = "jdbc:sql://localhost:3306/Covid19_db";
    private static final String USER = "Kishan";
    private static final String PASSWORD = "null";

    public static void main(String[] args) {
        ArrayList<ProvincialDetails> covidData = getProvincialDetailsFromDatabase();

        // Display detail
        displayProvincialDetails(covidData);
    }

    private static ArrayList<ProvincialDetails> getProvincialDetailsFromDatabase() {
        ArrayList<ProvincialDetails> data = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM provincial_data")) {

            while (resultSet.next()) {
                String province = resultSet.getString("province");
                int totalCases = resultSet.getInt("total_cases");
                double percentageTotal = resultSet.getDouble("percentage_total");

                //data.add(new ProvincialDetails(province, TotalCases, PercentageTotal));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }

    private static void displayProvincialDetails(ArrayList<ProvincialDetails> data) {
        for (ProvincialDetails details : data) {
            System.out.println(details);
 }
    }   



}


