/*INSERT INTO provincesWithCases (provinces,TotalCases,PercentageTotal)
VALUES ('Eastern Cape', '90686', '13'),
	   ('Free State', '50552', '7'),
	   ('Gauteng', '222745', '32'),
	   ('KwaZulu-Natal', '120295', '17'),
	   ('Limpop', '16233','2'),
	   ('Mpumalanga', '28115','4'),
	   ('North West', '301715', '4'),
	   ('Northern Cape', '18888', '3'),
	   ('Western Cape', '112667', '16')*/