
package game;

import java.util.Random;
import java.util.Scanner;
import java.util.TreeSet;


public class Game {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        TreeSet<Integer> correctAnswers = new TreeSet<>();

        System.out.println("Welcome to Edureka Trivia Game");

        while (true) {
            // Generate two random numbers and an operator
            int num1 = random.nextInt(10) + 1;
            int num2 = random.nextInt(10) + 1;
            char operator = getRandomOperator();

            // Display the problem
            
            System.out.print("what is " + num1 + " " + operator + " " + num2 +"? :");

            // Get the user's answer
            int userAnswer;
            try {
                userAnswer = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                continue;
            }

            // Check if the answer is correct
            if (calculateAnswer(num1, num2, operator) == userAnswer) {
                System.out.println("Welldone, that's correct!");
                correctAnswers.add(userAnswer);
            } else {
                System.out.println("Wrong Answer, the correct answer is: " + correctAnswers);
            }

            // Terminate the game if the user enters "999"
            if (userAnswer == 999) {
                break;
            }
        }

        // Display the correct answers vertically
        System.out.println("Thank you for playing");
        System.out.println("Correct answers in Hashset");
        for (int answer : correctAnswers) {
            System.out.println(answer);
        }
    }

    // Helper method to calculate the answer based on the numbers and operator
    private static int calculateAnswer(int num1, int num2, char operator) {
        switch (operator) {
            case '+':
                return num1 + num2;
            case '-':
                return num1 - num2;
            case '*':
                return num1 * num2;
            
                
            default:
                throw new IllegalArgumentException("Invalid operator");
        }
    }

    // Helper method to get a random operator (+, -, *, /)
    private static char getRandomOperator() {
        char[] operators = {'+', '-', '*',};
        Random random = new Random();
        return operators[random.nextInt(operators.length)];
        
        
    }
        
} 
    
      